import { check } from './utils/utils.js';
import './main.jsx';